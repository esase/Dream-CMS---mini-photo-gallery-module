DROP TABLE IF EXISTS `miniphotogallery_image`;
DROP TABLE IF EXISTS `miniphotogallery_category`;