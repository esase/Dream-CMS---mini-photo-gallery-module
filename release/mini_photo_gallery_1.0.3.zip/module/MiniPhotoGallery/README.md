# Mini photo gallery
Mini photo gallery module for Dream CMS. Module allows to publish a mini photo gallery on the site.
