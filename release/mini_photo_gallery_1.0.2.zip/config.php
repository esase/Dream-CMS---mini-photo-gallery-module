<?php 

return [
	'module_path' => 'module/MiniPhotoGallery',
    'layout_path' => 'layout/miniphotogallery'
];
