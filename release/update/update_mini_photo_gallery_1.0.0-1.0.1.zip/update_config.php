<?php 

return [
    'compatable' => '2.2.4',
    'module' => 'MiniPhotoGallery',
    'version' => '1.0.1',
    'vendor' => 'eSASe',
    'vendor_email' => 'alexermashev@gmail.com',
    'module_path' => 'module',
    'update_sql' => null,
    'update_intro' => null,
    'system_requirements' => [
    ],
    'module_depends' => [
    ],
    'clear_caches' => [
        'setting'       => false,
        'time_zone'     => false,
        'admin_menu'    => false,
        'js_cache'      => false,
        'css_cache'     => false,
        'layout'        => false,
        'localization'  => false,
        'page'          => false,
        'user'          => false,
        'xmlrpc'        => false
    ],
    'create_resources' => [
    ],
    'delete_resources' => [
    ]
];
