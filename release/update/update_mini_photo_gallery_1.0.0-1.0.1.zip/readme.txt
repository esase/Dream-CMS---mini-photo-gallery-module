MiniPhotoGallery update 1.0.1
System requirements: 
Module depends:

