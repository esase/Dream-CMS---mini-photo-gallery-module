<?php
namespace MiniPhotoGallery\Exception;
use Exception;

class MiniPhotoGalleryException extends Exception
{}